import streamlit as st
import matplotlib.pyplot as plt
from PIL import Image, ImageOps
import keras
import numpy as np
import ctypes
from ctypes import *
import Interop_MLP
#import LINEAR_MODEL_CPP_PYTHON

W = np.asarray([0.0064708, 0.39351262, 0.52752146, -0.70910594, -0.20860226, 0.37510133,
  0.35738206, -0.27239665, 0.84445564, -0.45738832, -0.87868809, -0.74283285,
  0.05587229,  0.76173555, -0.45823137,  0.45179029, -0.8739015,   0.5916342,
  0.44524642,  0.97826703,  0.14583319,  0.44096168,  0.75269042, -0.07847449,
 -0.38026569, -0.05137152,  0.95730918,-0.3329514,   0.58910983, 0.60547444,
  0.67324832,  0.24832962,  0.53489029,  0.57074251,  0.0834921,   0.17456301,
 -0.20698681, -0.05507783, -0.22688967, -0.42023604, -0.72888144, -0.93969394,
 -0.11287679, -0.44437918, -0.48836202,  0.33866435,  0.44972459, -0.69808549,
  0.29006686, -0.70097166,  0.01891316,  0.88620014,  0.33260402,  0.17377845,
  0.01416436, -0.7787085,  0.48664014])

#my_dll = ctypes.CDLL("/Users/mamadousarambounou/Desktop/ESGI/Bachelor2/2022/PROJET_ANNUEL/test_interop2/cmake-build-debug/libtest_interop2.dylib")

st.title("Projet annuel : MACHINE LEARNING")

def model_option():
    option = st.selectbox('Choisissez votre model',("TENSORFLOW/KERAS", 'LIBRARIE C++', 'LIBRARIE MLP'))
    st.write('Option:', option)
    return option

model_choice = model_option()

file_uploaded = st.file_uploader("Upload Files",type=['png','jpg', 'jpeg', 'gif', 'jfif'])

def predict_class():
    img_to_list = []
    model_tf_keras = keras.models.load_model('C:/Users/ariel/OneDrive/Bureau/ESGI/Bachelor/Projet Annuel/Python/MODEL_KERAS')
    image = ImageOps.grayscale(Image.open(file_uploaded).resize((56, 56)))

    if model_choice == "TENSORFLOW/KERAS":
        array = np.asarray(image).flatten().tolist()
        img_to_list.append(array)
        resultat = model_tf_keras.predict(img_to_list)
    elif model_choice == "LIBRARIE MLP":
        array = np.asarray(image).flatten().tolist()
        resultat = Interop_MLP.predict_mlp_without_model(array, len(array), 1)
    elif model_choice == "LIBRARIE C++":
        my_image = np.asarray(image, dtype=np.float64).flatten()
        resultat = my_dll.predict_linear_model(my_image, W, len(my_image))


    if resultat == -1:
        resultat = "It's a Woman !"
    else:
        resultat = "It's a Man !"
    return resultat


def main():
    if file_uploaded is not None:
        image = Image.open(file_uploaded)
        figure = plt.figure()
        plt.imshow(image)
        plt.axis("off")
        st.pyplot(figure)
        resultat = predict_class()
        st.write(resultat)

if __name__ == "__main__":
   main()