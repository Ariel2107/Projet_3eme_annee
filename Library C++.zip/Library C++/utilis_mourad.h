//
// Created by Noureddine SKB on 22/05/2022.
//

#ifndef PROJET_ANNUEL_UTILIS_MOURAD_H
#define PROJET_ANNUEL_UTILIS_MOURAD_H
#include <stdio.h>
#include <stdlib.h>
#include <vector>

std::vector<int> Append(std::vector<int> tab1, std::vector<int> tab2);
int* Append2(int *tab1, int* tab2);


#endif //PROJET_ANNUEL_UTILIS_MOURAD_H
