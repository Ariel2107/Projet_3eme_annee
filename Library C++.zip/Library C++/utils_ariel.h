//
// Created by ariel on 16/05/2022.
//

#ifndef PROJET_ANNUEL_UTILS_H
#define PROJET_ANNUEL_UTILS_H

float tanh_me(float z);

int sum(double* W, float* inputs);

#endif //PROJET_ANNUEL_UTILS_H
